package net.elizeu.android.aerolitos.scenes;

import org.igs.android.ogl.engine.Renderer;
import org.igs.android.ogl.engine.scene.Scene;

public class Configuration extends Scene {

	public Configuration(Renderer renderer) {
		super(renderer);
	}

	@Override
	public void enter() {
		
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void leave() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(float delta, float fps) {
		// TODO Auto-generated method stub
		
	}

}
